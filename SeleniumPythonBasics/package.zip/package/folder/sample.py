def sample():
    print("printing sample of folder")# with __init.py