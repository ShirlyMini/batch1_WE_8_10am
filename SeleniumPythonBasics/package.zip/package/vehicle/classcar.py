class car:
    def __init__(self):
        print("print class car consturctor")
