def motorcycle():
    print("printing motorcycler")