def sample():
    print("printing sample of folder1") # without __init.py