def sportscar():
    print("printing sports car")