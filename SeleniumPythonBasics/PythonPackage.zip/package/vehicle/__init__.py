# python to know folder package
# initiated at the time of import
print("print __init__.py")
user="shirly"
# explicit call of class/methods in folder
# from vehicle import car
# from vehicle import cycle
# from vehicle import classcar