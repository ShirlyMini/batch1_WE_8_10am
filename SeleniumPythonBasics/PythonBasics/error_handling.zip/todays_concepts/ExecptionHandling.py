# what is exeception?
# throwing error is exception---more 200 types of exception
# synaxerror, nameerror, valueerror, filenotfounderror, ioerror, ect
# lsit of execptions dir(builtin)
# import builtins

# print(dir(builtins))

# if 5>3---# syntax error
# print("5 is greater")

# print("d"+4) # Typeerror
# print(a)

# surpass your error and move on to the next line
# induce the error in the code

# two way- raise, assert
# raise

#itemincart = 0
# some add items operation your cart number should become 10
#if itemincart != 10:
    #raise Exception("item in the cart is not 10") # user can have any error like synatx, nameerror etc
# Execption is a generic one

# assert - check condition
#assert itemincart == 10, "item in the cart is not 10" # Assertionerror
#raise Exception("item in the cart is not 10 - raise")


