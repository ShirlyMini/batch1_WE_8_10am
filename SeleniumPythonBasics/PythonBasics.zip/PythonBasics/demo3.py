# for loop inter through dictionary
# dict1={1:"one", 2:"two", 3:"three"}
# print(dict1.items())
# for key, value in dict1.items():
#     print(key)
#     print(value)
#     if value=="two":
#         dict1[key]="four"
#     if key==3:
#         dict1[key]="six"
#
# print(dict1)
# print(dict1.keys())
# print(dict1.values())

# While loop

# syntax
# while condition:
#     Statements

n=7
while n>0:
    print(n)
    n-=1 #-- decrement
    #n+=1 -- increment