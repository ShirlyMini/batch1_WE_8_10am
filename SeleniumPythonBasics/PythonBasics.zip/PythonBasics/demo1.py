# print("hello")

# comments

# datatypes
# 1) numbers - int, float, complex
# a=1
# b=2.34
# c=3 +3j
# print("{}\n{}\n{}\n{}{}{}".format(a,b,c,a,b,c))
#
# print(f"{a} {b} {c} {a} {b} {b}")
#
# print(type(a))
# print(type(b))
# print(type(c))

# 2) Strings - array of bytes/ character
# a= "double quotes\n\t"
# b= r"single quotes\n\t"
#
# print(a)
# print(b)
#
# c="python hello world" #sting manipulation
#
# # print(c[0])
# # print(c[-1]) # reverse index
# #
# #print(c[0:5])
#
# # simple task - print output dlrow olleh nohtyp
# print(c[::-1])

# 3) List - array of heterogenous elements - immutable
#
# l = [1, 2.3, "s", "list"]
#
# print(l[0])
# print(l[-1])
# print(l[::-1])# import

# split str-> list
# join list -> string
str1= "python hello world"

#print(str1.split("hello"))

l = ["1", "2.3", "s", "list"] # join works only when the list elements are strings
#n1 = [1, 2.3] # join works only when the list elements are strings
#print("---".join(l))
# print(str(1))
# print(int("1"))

# print("python" + "world") # concatenation
# print("python" * 100)
# print(["j", 1, 2] * 100)



# tuple - same as list but immutable - changable
# t=(1, 2.3, "s", "list")
# print(t[0])
# print(t[-1])
# #t[0]= 100---throw error
# # t[4] = 1000 -----Throw error
# list1 = list(t)
# print(list1)
# list1.append("append")
# list1.insert(2,"insert")
# print(list1)
# del list1[3]
# print(tuple(list1))

# string declaration
# to comment single line #
"""a ="it's me python"
b ='"python"'
print(a, b)

# revesed
l1 = [3,55,22,11]
print(sorted(l1, reverse=True))
print(l1[::-1])"""
#list pop, extend, remove

#



