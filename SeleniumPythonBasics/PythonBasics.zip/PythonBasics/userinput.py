"""menu
1. add
2. sub
3. multiply"""

# a=input("enter a option <1-3> Interger value only") # string 1
# print(f"you have entered {a}")shirly
# print(int(a))
form=input("enter name")
print(form)
print(form.isalpha())
if form.isalpha()==False:
    print("ERROR")






